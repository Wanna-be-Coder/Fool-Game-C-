﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foolmine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {

            Button b = (Button)sender;
            Random r = new Random();

            int x = r.Next(416 - 1);
            int y = r.Next(398 - 1);

            b.Location= new Point(x,y);
            b.Size = new Size(75, 23);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("STILL A FOOL!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yolo!");
        }
    }
}
